﻿namespace API.ReceiveMessages
{
    public interface IStoreMessage
    {
        bool SaveMessateAtFile(string message);
    }
}