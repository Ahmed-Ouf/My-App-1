﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace API.ReceiveMessages
{
    public class QMBackGroundService : BackgroundService
    {
        private readonly IWorker worker;

        public QMBackGroundService(IWorker worker)
        {
            this.worker = worker;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
          await  worker.DoWorkAsync(stoppingToken);
        }
    }
}
