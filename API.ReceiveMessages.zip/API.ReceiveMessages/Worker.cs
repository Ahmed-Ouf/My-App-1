﻿using IBM.XMS;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace API.ReceiveMessages
{
    public class Worker : IWorker
    {
        private readonly ILogger<Worker> logger;
        private readonly IStoreMessage storeMessage;
        private int number;
        private IMessage msg;
        IConnection conn = null;
        ISession sess = null;
        IMessageConsumer consumer = null;
        IDestination dest = null;

        public Worker(ILogger<Worker> logger, IStoreMessage storeMessage)
        {
            this.logger = logger;
            this.storeMessage = storeMessage;
        }
        public async Task DoWorkAsync(CancellationToken cancellationToken)
        {
            try
            {
                IMessageConsumer consumer = GetConsumer();

                while (!cancellationToken.IsCancellationRequested)
                {
                    Interlocked.Increment(ref number);
                    logger.LogInformation($"Worker printing number : {number}");
                    ReceiveMessage(consumer);
                    await Task.Delay(1000 * 5);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                throw ex;
            }
            finally
            {
                logger.LogInformation("worker Shutdown");
                CleanUp();
            }

        }

        private void CleanUp()
        {
            consumer.Close();
            dest.Dispose();
            sess.Dispose();
            conn.Close();
        }

        public IMessageConsumer GetConsumer()
        {
            XMSFactoryFactory xff = XMSFactoryFactory.GetInstance(XMSC.CT_WMQ);
            IConnectionFactory cf = xff.CreateConnectionFactory();
            cf.SetStringProperty(XMSC.WMQ_HOST_NAME, "10.14.8.25(9702)");
            cf.SetIntProperty(XMSC.WMQ_PORT, 9702);
            cf.SetStringProperty(XMSC.WMQ_CHANNEL, "APP.ETIMAD");
            cf.SetIntProperty(XMSC.WMQ_CONNECTION_MODE, XMSC.WMQ_CM_CLIENT);
            cf.SetStringProperty(XMSC.WMQ_QUEUE_MANAGER, "APPLN01T");
            cf.SetIntProperty(XMSC.WMQ_BROKER_VERSION, XMSC.WMQ_BROKER_V1);

            IConnection conn = cf.CreateConnection();
            Debug.WriteLine("connection created");
            ISession sess = conn.CreateSession(false, AcknowledgeMode.ClientAcknowledge);

            IDestination dest = sess.CreateQueue("Etimad.TestRqBackout");
            conn.ExceptionListener = new ExceptionListener(OnException);
            IMessageConsumer consumer = sess.CreateConsumer(dest);
            conn.Start();
            return consumer;
        }

        public void ReceiveMessage(IMessageConsumer consumer)
        {
            IMessage receivedMessage = consumer.Receive();
            OnMessage(receivedMessage);
        }

        static void OnException(Exception ex)
        {
            Debug.WriteLine("Error");
            Debug.WriteLine(ex);
        }

        private void OnMessage(IMessage msg)
        {
            Debug.WriteLine(msg);
            this.msg = msg;
            ITextMessage textMsg = (ITextMessage)msg;
            // we can make trans action if don 
            if (storeMessage.SaveMessateAtFile(textMsg.Text))
            {
                msg.Acknowledge();
            }
            Debug.Write("Got a message: ");
            Debug.WriteLine(textMsg.Text);
        }

    }
}
