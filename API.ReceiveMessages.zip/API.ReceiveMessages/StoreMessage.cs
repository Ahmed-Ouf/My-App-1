﻿using Microsoft.Extensions.Logging;

namespace API.ReceiveMessages
{
    public class StoreMessage : IStoreMessage
    {
        private readonly Logger<StoreMessage> logger;
        private readonly ILogWriter logWriter;

        public StoreMessage(Logger<StoreMessage> logger, ILogWriter logWriter)
        {
            this.logger = logger;
            this.logWriter = logWriter;
        }


        public bool SaveMessateAtFile(string message)
        {
            try
            {
                logWriter.LogWrite(message);
                return true;
            }
            catch
            {
                return false;
            }

        }
    }
}
