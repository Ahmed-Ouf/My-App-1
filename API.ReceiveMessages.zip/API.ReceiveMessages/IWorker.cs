﻿using System.Threading;
using System.Threading.Tasks;

namespace API.ReceiveMessages
{
    public interface IWorker
    {
        Task DoWorkAsync(CancellationToken cancellationToken);
    }
}